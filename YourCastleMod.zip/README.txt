Installation Instructions:
1. Extract the YourCastleMod folder into Documents\Mount and Blade II Bannerlord\Modules\
2. Enable YourCastleMod in the game launcher
3. Enjoy your new castle!
